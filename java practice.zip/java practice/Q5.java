class Sample
{
    public static void main(String args[]){
        int arr[]
        int arr[]=[23,45,56,67,90,45,23]
        for(int i=0;i<arr.length;i++){
            for(int j=i+1;j<arr.length;j++){
                if(arr[]==arr[i]){
                arr[j]=0;
                }
            }
            if(arr[i]<0){
            System.out.print(arr[i]);
            }
            fr=1;
        }
    }
    
}