class Q4
{
    public static void main(String args[]){
        int fr=1;
        int arr[]={23,-45,56,-67,90,-45,23};
        int arr1[]=new int[arr.length];
        int arr2[]=new int[arr.length];
        for(int i=0;i<arr.length;i++){
                if(arr[i]>=0){
                    arr1[]=arr[i];
                fr++;
                }
            }
            else{
                arr2[]=arr[i];
            System.out.print(arr1[]);
            System.out.print(arr2[])
            }
            fr=1;
        }
    }
    
}