class Q21 {
    
    public static void main(String args[]){
     
       String str="hi hello";
       
       str.concat(" bitLabs");
       System.out.println(str);
      
         
    }
}