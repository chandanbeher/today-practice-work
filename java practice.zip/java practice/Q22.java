class Q22{
    
    public static void main(String args[]){
     
       String str="hi hello";
       
       str=str.concat(" bitLabs");
       System.out.println(str);
      
         
    }
    
}