class Q24 {
    
    public static void main(String args[]){
     
     String str="hi hello bitLabs hi hello";
     
     String words[]=str.split(" ");
     System.out.println("Number of words : "+words.length);
         
    }
    
}