class Q23 {
    
    public static void main(String args[]){
     
       StringBuffer str=new StringBuffer("hi hello");
       
       str.append(" bitLabs");
       System.out.println(str);
      
         
    }
    
}